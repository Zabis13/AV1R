#' @useDynLib AV1R, .registration = TRUE
"_PACKAGE"
